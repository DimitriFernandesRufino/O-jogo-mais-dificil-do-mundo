var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":[],"propsByKey":{}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

//creating the game project
var Sofia = createSprite(20,25,18,18);
Sofia.shapeColor = "DarkBlue";

var taça = createSprite(430,385);
taça.shapeColor = "Green"

var papelao1 = createSprite(10,70,100,20);
papelao1.shapeColor = "Blue"

var papelao2 = createSprite(105,4,20,190);
papelao2.shapeColor = "Blue"

var papelao3 = createSprite(145,25,100,20);
papelao3.shapeColor = "Blue"

var papelao4 = createSprite(90,125,90,20);
papelao4.shapeColor = "Blue"

var papelao5 = createSprite(171,118,20,100);
papelao5.shapeColor = "Blue"

var papelao6 = createSprite(249,72,20,100);
papelao6.shapeColor = "Blue"

var papelao7 = createSprite(325,57,90,20);
papelao7.shapeColor = "Blue"

var papelao8 = createSprite(265,150,90,20);
papelao8.shapeColor = "Blue"

var papelao9 = createSprite(335,130,20,100);
papelao9.shapeColor = "Blue"

var papelao10 = createSprite(67,230,20,100);
papelao10.shapeColor = "Blue"

var papelao11 = createSprite(28,225,98,20);
papelao11.shapeColor = "Blue"

var papelao12 = createSprite(47,335,20,125);
papelao12.shapeColor = "Blue"

var papelao13 = createSprite(107,291,20,100);
papelao13.shapeColor = "Blue"

var papelao14 = createSprite(145,190,90,20);
papelao14.shapeColor = "Blue"

var papelao15 = createSprite(186,300,90,20);
papelao15.shapeColor = "Blue"

var papelao16 = createSprite(183,342,20,100);
papelao16.shapeColor = "Blue"

var papelao17 = createSprite(222,245,20,130);
papelao17.shapeColor = "Blue"

var papelao18 = createSprite(332, 190,150,20);
papelao18.shapeColor = "Blue"

var papelao19 = createSprite(248, 382,90,20);
papelao19.shapeColor = "Blue"

var papelao20 = createSprite(315,344,20,100);
papelao20.shapeColor = "Blue"

var papelao21 = createSprite(345,244,120,20);
papelao21.shapeColor = "Blue"

var papelao22 = createSprite(275,264,20,110);
papelao22.shapeColor = "Blue"

function draw() {
 background("LightBlue");
  
  if (keyDown(UP_ARROW)) {
   
Sofia.velocityX=0;
Sofia.velocityY=4;
  }
  if (keyDown(DOWN_ARROW)) {
    
Sofia.velocityX=0;
Sofia.velocityY=4;
  }
  if (keyDown(LEFT_ARROW)) {
    
Sofia.velocityX=4;
Sofia.velocityY=0;
    
  }
  if (keyDown(RIGHT_ARROW)) {
    
Sofia.velocityX=4;
Sofia.velocityY=0;
    
  }
  
createEdgeSprites();
Sofia.bounceOff(edges);   
  
Sofia.bounceOff(papelao1);
Sofia.bounceOff(papelao2);
Sofia.bounceOff(papelao3);
Sofia.bounceOff(papelao4);
Sofia.bounceOff(papelao5);
Sofia.bounceOff(papelao6);
Sofia.bounceOff(papelao7);
Sofia.bounceOff(papelao8);
Sofia.bounceOff(papelao9);
Sofia.bounceOff(papelao10);
Sofia.bounceOff(papelao11);
Sofia.bounceOff(papelao12);
Sofia.bounceOff(papelao13);
Sofia.bounceOff(papelao14);
Sofia.bounceOff(papelao15);
Sofia.bounceOff(papelao16);
Sofia.bounceOff(papelao17);
Sofia.bounceOff(papelao18);
Sofia.bounceOff(papelao19);
Sofia.bounceOff(papelao20);
Sofia.bounceOff(papelao21);
Sofia.bounceOff(papelao22);
             
Sofia.bounceOff(taça);
    
  
  drawSprites();
  
  
  
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
